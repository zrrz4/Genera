#ifndef SECCOMPUTILS_H
#define SECCOMPUTILS_H

namespace SeccompUtils {
    void init();
}

#endif // SECCOMPUTILS_H
