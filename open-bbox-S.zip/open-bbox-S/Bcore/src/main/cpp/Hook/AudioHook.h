#ifndef AUDIOHOOK_H
#define AUDIOHOOK_H

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

void AudioHook_init(JNIEnv *env);

#ifdef __cplusplus
}
#endif

#endif