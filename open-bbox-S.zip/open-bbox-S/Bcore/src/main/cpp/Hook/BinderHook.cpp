//
// Created by Milk on 4/25/21.
// Updated for Android 16 Audio Fix
//

#include "BinderHook.h"
#include <IO.h>
#include <BoxCore.h>
#include "UnixFileSystemHook.h"
#import "JniHook/JniHook.h"

HOOK_JNI(jint, getCallingUid, JNIEnv *env, jobject obj) {
    int orig = orig_getCallingUid(env, obj);
    return BoxCore::getCallingUid(env, orig);
}

HOOK_JNI(jint, getCallingPid, JNIEnv *env, jobject obj) {
    return orig_getCallingPid(env, obj);
}

HOOK_JNI(jint, checkAudioPermission, JNIEnv *env, jclass clazz, jstring permission, jint pid, jint uid) {
    if (BoxCore::getApiLevel() >= 36) {
        return 1;
    }
    return orig_checkAudioPermission(env, clazz, permission, pid, uid);
}

void BinderHook::init(JNIEnv *env) {
    const char *clazz = "android/os/Binder";
    JniHook::HookJniFun(env, clazz, "getCallingUid", "()I", 
                        (void *) new_getCallingUid,
                        (void **) (&orig_getCallingUid), true);
    
    JniHook::HookJniFun(env, clazz, "getCallingPid", "()I",
                        (void *) new_getCallingPid,
                        (void **) (&orig_getCallingPid), true);
    
    if (BoxCore::getApiLevel() >= 36) {
        const char *audioService = "android/media/IAudioService$Stub";
        jclass audioStub = env->FindClass(audioService);
        if (audioStub) {
            JniHook::HookJniFun(env, audioService, "checkAudioPermission", 
                               "(Ljava/lang/String;II)I",
                               (void *) new_checkAudioPermission,
                               (void **) (&orig_checkAudioPermission), true);
        }
        env->ExceptionClear();
    }
}