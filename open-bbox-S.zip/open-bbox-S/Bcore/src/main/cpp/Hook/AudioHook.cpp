#include "AudioHook.h"
#include "JniHook/JniHook.h"
#include "BoxCore.h"
#include <sys/stat.h>

HOOK_JNI(jint, getMinBufferSize, JNIEnv *env, jobject obj, jint sampleRateInHz, jint channelConfig, jint audioFormat) {
    return orig_getMinBufferSize(env, obj, sampleRateInHz, channelConfig, audioFormat);
}

HOOK_JNI(jint, nativeSetup, JNIEnv *env, jobject obj, jobject audioAttributes, jobject audioFormat, jobject androidOSHandler, jint sessionId) {
    return orig_nativeSetup(env, obj, audioAttributes, audioFormat, androidOSHandler, sessionId);
}

HOOK_JNI(jint, nativeStart, JNIEnv *env, jobject obj) {
    return orig_nativeStart(env, obj);
}

HOOK_JNI(void, nativeStop, JNIEnv *env, jobject obj) {
    orig_nativeStop(env, obj);
}

HOOK_JNI(jint, nativeCheckAccess, JNIEnv *env, jclass clazz, jstring packageName, jint pid, jint uid) {
    if (BoxCore::getApiLevel() >= 36) {
        return 1;
    }
    return orig_nativeCheckAccess(env, clazz, packageName, pid, uid);
}

HOOK_JNI(jint, nativeGetOutputLatency, JNIEnv *env, jclass clazz, jint streamType) {
    return orig_nativeGetOutputLatency(env, clazz, streamType);
}

static void hookAudioRecord(JNIEnv *env) {
    const char *audioRecord = "android/media/AudioRecord";
    
    JniHook::HookJniFun(env, audioRecord, "getMinBufferSize", 
                       "(III)I", 
                       (void *) new_getMinBufferSize,
                       (void **) (&orig_getMinBufferSize), true);
    
    JniHook::HookJniFun(env, audioRecord, "native_setup", 
                       "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)I",
                       (void *) new_nativeSetup,
                       (void **) (&orig_nativeSetup), false);
    
    JniHook::HookJniFun(env, audioRecord, "native_start", 
                       "(II)I",
                       (void *) new_nativeStart,
                       (void **) (&orig_nativeStart), false);
    
    JniHook::HookJniFun(env, audioRecord, "native_stop", 
                       "()V",
                       (void *) new_nativeStop,
                       (void **) (&orig_nativeStop), false);
}

static void hookAudioSystem(JNIEnv *env) {
    const char *audioSystem = "android/media/AudioSystem";
    
    JniHook::HookJniFun(env, audioSystem, "native_check_permission", 
                       "(Ljava/lang/String;II)I",
                       (void *) new_nativeCheckAccess,
                       (void **) (&orig_nativeCheckAccess), true);
    
    JniHook::HookJniFun(env, audioSystem, "getOutputLatency", 
                       "(I)I",
                       (void *) new_nativeGetOutputLatency,
                       (void **) (&orig_nativeGetOutputLatency), true);
}

static void hookMediaRecorder(JNIEnv *env) {
    const char *mediaRecorder = "android/media/MediaRecorder";
    
    JniHook::HookJniFun(env, mediaRecorder, "native_setup", 
                       "(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V",
                       (void *) new_nativeSetup,
                       (void **) (&orig_nativeSetup), false);
}

void AudioHook_init(JNIEnv *env) {
    if (BoxCore::getApiLevel() >= 36) {
        hookAudioRecord(env);
        hookAudioSystem(env);
        hookMediaRecorder(env);
    }
}