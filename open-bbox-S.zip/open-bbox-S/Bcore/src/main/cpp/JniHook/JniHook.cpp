#include <jni.h>
#include <string>
#include <vector>
#include <cstring>
#include <sys/mman.h>
#include <unistd.h>
#include "JniHook.h"
#include "ArtMethod.h"

extern "C" {
    __attribute__((section(".mytext"))) JNICALL void native_offset(JNIEnv *env, jclass obj);
    __attribute__((section(".mytext"))) JNICALL void native_offset2(JNIEnv *env, jclass obj);
}

static struct {
    int api_level;
    unsigned int art_field_size;
    int art_field_flags_offset;
    unsigned int art_method_size;
    int art_method_flags_offset;
    int art_method_native_offset;
    int class_flags_offset;
    jclass method_utils_class;
    jmethodID get_method_desc_id;
    jmethodID get_method_declaring_class_id;
    jmethodID get_method_name_id;
    bool initialized_successfully;
} HookEnv = {0};

static std::string GetJString(JNIEnv *env, jstring jstr) {
    if (!jstr) return std::string();
    const char *s = env->GetStringUTFChars(jstr, JNI_FALSE);
    if (!s) return std::string();
    std::string out(s);
    env->ReleaseStringUTFChars(jstr, s);
    return out;
}

static const char *GetMethodDesc(JNIEnv *env, jobject javaMethod) {
    if (!HookEnv.method_utils_class) return nullptr;
    jstring desc = (jstring) env->CallStaticObjectMethod(HookEnv.method_utils_class, HookEnv.get_method_desc_id, javaMethod);
    if (!desc) return nullptr;
    return env->GetStringUTFChars(desc, JNI_FALSE);
}

static const char *GetMethodDeclaringClass(JNIEnv *env, jobject javaMethod) {
    if (!HookEnv.method_utils_class) return nullptr;
    jstring desc = (jstring) env->CallStaticObjectMethod(HookEnv.method_utils_class, HookEnv.get_method_declaring_class_id, javaMethod);
    if (!desc) return nullptr;
    return env->GetStringUTFChars(desc, JNI_FALSE);
}

static const char *GetMethodName(JNIEnv *env, jobject javaMethod) {
    if (!HookEnv.method_utils_class) return nullptr;
    jstring desc = (jstring) env->CallStaticObjectMethod(HookEnv.method_utils_class, HookEnv.get_method_name_id, javaMethod);
    if (!desc) return nullptr;
    return env->GetStringUTFChars(desc, JNI_FALSE);
}

static bool MakeWritable(void *addr, size_t len) {
    if (!addr || len == 0) return false;
    long page_size = getpagesize();
    if (page_size <= 0) return false;
    uintptr_t start_addr = (uintptr_t)addr;
    uintptr_t end_addr = start_addr + len - 1;
    uintptr_t page_start = start_addr & ~(page_size - 1);
    uintptr_t page_end = (end_addr + page_size) & ~(page_size - 1);
    size_t region_size = page_end - page_start;
    return mprotect((void *)page_start, region_size, PROT_READ | PROT_WRITE) == 0;
}

inline static uint32_t GetAccessFlags(const char *art_method) {
    if (!art_method || HookEnv.art_method_flags_offset <= 0) return 0;
    return *reinterpret_cast<const uint32_t *>(art_method + HookEnv.art_method_flags_offset);
}

inline static bool SetAccessFlags(char *art_method, uint32_t flags) {
    if (!art_method || HookEnv.art_method_flags_offset <= 0) return false;
    void *addr = art_method + HookEnv.art_method_flags_offset;
    if (!MakeWritable(addr, sizeof(uint32_t))) return false;
    *reinterpret_cast<uint32_t *>(addr) = flags;
    return true;
}

inline static bool AddAccessFlag(char *art_method, uint32_t flag) {
    uint32_t old_flag = GetAccessFlags(art_method);
    uint32_t new_flag = old_flag | flag;
    return new_flag != old_flag && SetAccessFlags(art_method, new_flag);
}

inline static bool ClearAccessFlag(char *art_method, uint32_t flag) {
    uint32_t old_flag = GetAccessFlags(art_method);
    uint32_t new_flag = old_flag & ~flag;
    return new_flag != old_flag && SetAccessFlags(art_method, new_flag);
}

inline static bool HasAccessFlag(char *art_method, uint32_t flag) {
    uint32_t flags = GetAccessFlags(art_method);
    return (flags & flag) == flag;
}

inline static bool ClearFastNativeFlag(char *art_method) {
    return HookEnv.api_level < __ANDROID_API_P__ && ClearAccessFlag(art_method, kAccFastNative);
}

static void *GetArtMethod(JNIEnv *env, jclass clazz, jmethodID methodId) {
    if (!env || !clazz || !methodId) return nullptr;
    if (HookEnv.api_level >= __ANDROID_API_Q__) {
        jclass executable = env->FindClass("java/lang/reflect/Executable");
        if (!executable) return nullptr;
        jfieldID artId = env->GetFieldID(executable, "artMethod", "J");
        if (!artId) return nullptr;
        jobject method = env->ToReflectedMethod(clazz, methodId, true);
        if (!method) return nullptr;
        return reinterpret_cast<void *>(env->GetLongField(method, artId));
    } else {
        return methodId;
    }
}

static void *GetFieldMethod(JNIEnv *env, jobject field) {
    if (!env || !field) return nullptr;
    if (HookEnv.api_level >= __ANDROID_API_Q__) {
        jclass fieldClass = env->FindClass("java/lang/reflect/Field");
        if (!fieldClass) return nullptr;
        jmethodID getArtField = env->GetMethodID(fieldClass, "getArtField", "()J");
        if (!getArtField) return nullptr;
        return reinterpret_cast<void *>(env->CallLongMethod(field, getArtField));
    } else {
        return env->FromReflectedField(field);
    }
}

static bool CheckFlags(void *artMethod) {
    if (!artMethod) return false;
    char *method = static_cast<char *>(artMethod);
    if (!HasAccessFlag(method, kAccNative)) return false;
    ClearFastNativeFlag(method);
    return true;
}

void JniHook::HookJniFun(JNIEnv *env, jobject java_method, void *new_fun, void **orig_fun, bool is_static) {
    if (!env || !java_method || !new_fun) return;
    if (!HookEnv.initialized_successfully) return;

    const char *class_name_ptr = GetMethodDeclaringClass(env, java_method);
    const char *method_name_ptr = GetMethodName(env, java_method);
    const char *sign_ptr = GetMethodDesc(env, java_method);

    if (!class_name_ptr || !method_name_ptr || !sign_ptr) {
        if (class_name_ptr) env->ReleaseStringUTFChars((jstring)class_name_ptr, class_name_ptr);
        if (method_name_ptr) env->ReleaseStringUTFChars((jstring)method_name_ptr, method_name_ptr);
        if (sign_ptr) env->ReleaseStringUTFChars((jstring)sign_ptr, sign_ptr);
        return;
    }

    std::string class_name = GetJString(env, (jstring)class_name_ptr);
    std::string method_name = GetJString(env, (jstring)method_name_ptr);
    std::string sign = GetJString(env, (jstring)sign_ptr);

    env->ReleaseStringUTFChars((jstring)class_name_ptr, class_name_ptr);
    env->ReleaseStringUTFChars((jstring)method_name_ptr, method_name_ptr);
    env->ReleaseStringUTFChars((jstring)sign_ptr, sign_ptr);

    HookJniFun(env, class_name.c_str(), method_name.c_str(), sign.c_str(), new_fun, orig_fun, is_static);
}

void JniHook::HookJniFun(JNIEnv *env, const char *class_name, const char *method_name, const char *sign, void *new_fun, void **orig_fun, bool is_static) {
    if (!env || !class_name || !method_name || !sign || !new_fun) return;
    if (!HookEnv.initialized_successfully) return;
    if (HookEnv.art_method_native_offset <= 0) return;

    jclass clazz = env->FindClass(class_name);
    if (!clazz) {
        env->ExceptionClear();
        return;
    }

    jmethodID method = is_static ? env->GetStaticMethodID(clazz, method_name, sign) : env->GetMethodID(clazz, method_name, sign);
    if (!method) {
        env->ExceptionClear();
        return;
    }

    auto artMethod = reinterpret_cast<uintptr_t *>(GetArtMethod(env, clazz, method));
    if (!artMethod) return;
    if (!CheckFlags(artMethod)) return;

    if (orig_fun) {
        *orig_fun = reinterpret_cast<void *>(artMethod[HookEnv.art_method_native_offset]);
    }

    JNINativeMethod gMethods[] = {{const_cast<char *>(method_name), const_cast<char *>(sign), new_fun}};
    if (env->RegisterNatives(clazz, gMethods, 1) < 0) {
        env->ExceptionClear();
        return;
    }

    if (HookEnv.api_level == __ANDROID_API_O__ || HookEnv.api_level == __ANDROID_API_O_MR1__) {
        AddAccessFlag((char *)artMethod, kAccFastNative);
    }
}

static bool FindOffsetsAlternative(JNIEnv *env, void *nativeOffset, void *nativeOffset2) {
    auto artMethod = reinterpret_cast<uintptr_t *>(nativeOffset);
    size_t methodSize = (size_t)nativeOffset2 - (size_t)nativeOffset;

    uintptr_t codeStart = (uintptr_t)&native_offset;
    uintptr_t codeEnd = (uintptr_t)&native_offset2;

    for (size_t i = 0; i < methodSize / sizeof(uintptr_t); ++i) {
        uintptr_t value = artMethod[i];
        if (value >= codeStart && value <= codeEnd + 0x1000) {
            HookEnv.art_method_native_offset = i;
            break;
        }
    }

    if (HookEnv.art_method_native_offset == 0) return false;

    uint32_t possibleFlags[] = {
        kAccPublic | kAccStatic | kAccNative,
        kAccPublic | kAccStatic | kAccNative | kAccFinal,
        kAccPublic | kAccStatic | kAccNative | kAccFinal | kAccNterpInvokeFastPathFlag,
        0x0011, 0x1011, 0x2011, 0x0811
    };

    char *start = reinterpret_cast<char *>(artMethod);
    for (size_t i = 1; i < methodSize / sizeof(uint32_t); ++i) {
        uint32_t value = *(uint32_t *)(start + i * sizeof(uint32_t));
        for (int f = 0; f < sizeof(possibleFlags)/sizeof(possibleFlags[0]); ++f) {
            if (value == possibleFlags[f] || (value & possibleFlags[f]) == possibleFlags[f]) {
                HookEnv.art_method_flags_offset = i * sizeof(uint32_t);
                break;
            }
        }
        if (HookEnv.art_method_flags_offset != 0) break;
    }

    return HookEnv.art_method_native_offset != 0 && HookEnv.art_method_flags_offset != 0;
}

extern "C" {

__attribute__((section(".mytext"))) JNICALL void native_offset(JNIEnv *env, jclass obj) {}
__attribute__((section(".mytext"))) JNICALL void native_offset2(JNIEnv *env, jclass obj) {}

__attribute__((section(".mytext"))) JNICALL void set_method_accessible(JNIEnv *env, jclass obj, jclass clazz, jobject method) {
    if (!env || !clazz || !method) return;
    jmethodID methodId = env->FromReflectedMethod(method);
    char *art_method = static_cast<char *>(GetArtMethod(env, clazz, methodId));
    if (!art_method) return;
    AddAccessFlag(art_method, kAccPublic);
    if (HookEnv.api_level >= __ANDROID_API_Q__) {
        AddAccessFlag(art_method, kAccPublicApi);
    }
}

__attribute__((section(".mytext"))) JNICALL void set_field_accessible(JNIEnv *env, jclass obj, jclass clazz, jobject field) {
    if (!env || !field) return;
    char *artField = static_cast<char *>(GetFieldMethod(env, field));
    if (!artField) return;
    AddAccessFlag(artField, kAccPublic);
    ClearAccessFlag(artField, kAccFinal);
    if (HookEnv.api_level >= __ANDROID_API_Q__) {
        AddAccessFlag(artField, kAccPublicApi);
    }
}

}

static void registerNative(JNIEnv *env) {
    if (!env) return;
    jclass clazz = env->FindClass("top/niunaijun/jnihook/jni/JniHook");
    if (!clazz) return;
    JNINativeMethod gMethods[] = {
        {"nativeOffset",  "()V", (void*)&native_offset},
        {"nativeOffset2", "()V", (void*)&native_offset2},
        {"setAccessible", "(Ljava/lang/Class;Ljava/lang/reflect/Method;)V", (void*)&set_method_accessible},
        {"setAccessible", "(Ljava/lang/Class;Ljava/lang/reflect/Field;)V",  (void*)&set_field_accessible},
    };
    env->RegisterNatives(clazz, gMethods, 4);
}

void JniHook::InitJniHook(JNIEnv *env, int api_level) {
    if (!env) return;

    HookEnv.api_level = api_level;
    HookEnv.art_method_native_offset = 0;
    HookEnv.art_method_flags_offset = 0;
    HookEnv.initialized_successfully = false;

    registerNative(env);

    jclass clazz = env->FindClass("top/niunaijun/jnihook/jni/JniHook");
    if (!clazz) return;

    jmethodID nativeOffsetId = env->GetStaticMethodID(clazz, "nativeOffset", "()V");
    jmethodID nativeOffset2Id = env->GetStaticMethodID(clazz, "nativeOffset2", "()V");
    if (!nativeOffsetId || !nativeOffset2Id) return;

    jfieldID nativeOffsetFieldId = env->GetStaticFieldID(clazz, "NATIVE_OFFSET", "I");
    jfieldID nativeOffsetField2Id = env->GetStaticFieldID(clazz, "NATIVE_OFFSET_2", "I");
    if (!nativeOffsetFieldId || !nativeOffsetField2Id) return;

    void *nativeOffsetField = GetFieldMethod(env, env->ToReflectedField(clazz, nativeOffsetFieldId, true));
    void *nativeOffsetField2 = GetFieldMethod(env, env->ToReflectedField(clazz, nativeOffsetField2Id, true));
    if (!nativeOffsetField || !nativeOffsetField2) return;
    HookEnv.art_field_size = (size_t) nativeOffsetField2 - (size_t) nativeOffsetField;

    void *nativeOffset = GetArtMethod(env, clazz, nativeOffsetId);
    void *nativeOffset2 = GetArtMethod(env, clazz, nativeOffset2Id);
    if (!nativeOffset || !nativeOffset2) return;
    HookEnv.art_method_size = (size_t) nativeOffset2 - (size_t) nativeOffset;

    bool offsetsFound = false;
    auto artMethod = reinterpret_cast<uintptr_t *>(nativeOffset);
    for (int i = 0; i < HookEnv.art_method_size / sizeof(uintptr_t); ++i) {
        if (reinterpret_cast<void *>(artMethod[i]) == (void*)&native_offset) {
            HookEnv.art_method_native_offset = i;
            offsetsFound = true;
            break;
        }
    }

    if (!offsetsFound) {
        offsetsFound = FindOffsetsAlternative(env, nativeOffset, nativeOffset2);
    }

    if (!offsetsFound) return;

    uint32_t searchFlags = kAccPublic | kAccStatic | kAccNative;
    if (api_level >= __ANDROID_API_Q__) searchFlags |= kAccPublicApi;
    if (api_level >= 36) searchFlags |= kAccNterpInvokeFastPathFlag;

    std::vector<uint32_t> possibleFlags;
    possibleFlags.push_back(searchFlags);
    possibleFlags.push_back(searchFlags | kAccFinal);
    possibleFlags.push_back(searchFlags | kAccSynchronized);
    possibleFlags.push_back(searchFlags | kAccFinal | kAccNterpInvokeFastPathFlag);
    possibleFlags.push_back(searchFlags | kAccFastNative);

    char *start = reinterpret_cast<char *>(artMethod);
    bool flagsFound = false;
    for (int i = 1; i < HookEnv.art_method_size / sizeof(uint32_t); ++i) {
        uint32_t value = *(uint32_t *)(start + i * sizeof(uint32_t));
        for (uint32_t flags : possibleFlags) {
            if (value == flags) {
                HookEnv.art_method_flags_offset = i * sizeof(uint32_t);
                flagsFound = true;
                break;
            }
        }
        if (flagsFound) break;
    }

    if (!flagsFound) {
        HookEnv.art_method_flags_offset = 4 * sizeof(uint32_t);
    }

    char *fieldStart = reinterpret_cast<char *>(nativeOffsetField);
    for (int i = 1; i < HookEnv.art_field_size / sizeof(int32_t); ++i) {
        auto value = *(int32_t *)(fieldStart + i * sizeof(int32_t));
        if (value == (kAccPublic | kAccStatic | kAccFinal)) {
            HookEnv.art_field_flags_offset = i * sizeof(int32_t);
            break;
        }
    }

    jclass methodUtilsClass = env->FindClass("top/niunaijun/jnihook/MethodUtils");
    if (!methodUtilsClass) return;
    HookEnv.method_utils_class = (jclass)env->NewGlobalRef(methodUtilsClass);

    HookEnv.get_method_desc_id = env->GetStaticMethodID(HookEnv.method_utils_class, "getDesc", "(Ljava/lang/reflect/Method;)Ljava/lang/String;");
    HookEnv.get_method_declaring_class_id = env->GetStaticMethodID(HookEnv.method_utils_class, "getDeclaringClass", "(Ljava/lang/reflect/Method;)Ljava/lang/String;");
    HookEnv.get_method_name_id = env->GetStaticMethodID(HookEnv.method_utils_class, "getMethodName", "(Ljava/lang/reflect/Method;)Ljava/lang/String;");

    if (!HookEnv.get_method_desc_id || !HookEnv.get_method_declaring_class_id || !HookEnv.get_method_name_id) return;

    HookEnv.initialized_successfully = true;
}