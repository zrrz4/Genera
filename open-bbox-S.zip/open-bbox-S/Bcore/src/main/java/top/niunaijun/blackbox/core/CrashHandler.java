package top.niunaijun.blackbox.core;

import android.util.Log;
import top.niunaijun.blackbox.BlackBoxCore;

// ╔══════════════════════════════════════════════════════════╗
// ║       MAFIA BBOX SDK — CrashHandler (ENHANCED)          ║
// ║  ✅ حماية أقوى من الكراشات وتسجيل الأخطاء              ║
// ╚══════════════════════════════════════════════════════════╝
public class CrashHandler implements Thread.UncaughtExceptionHandler {

    private static final String TAG = "MetaCrashHandler";
    private Thread.UncaughtExceptionHandler mDefaultHandler;

    public static void create() {
        new CrashHandler();
    }

    public CrashHandler() {
        mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(this);
    }

    @Override
    public void uncaughtException(Thread t, Throwable e) {
        try {
            Log.e(TAG, "Uncaught exception in thread: " + t.getName(), e);

            // استدعاء Handler المخصص إن وجد
            Thread.UncaughtExceptionHandler custom = null;
            try {
                custom = BlackBoxCore.get().getExceptionHandler();
            } catch (Throwable ignored) {}

            if (custom != null) {
                try { custom.uncaughtException(t, e); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {
            // لا نسمح للـ CrashHandler نفسه أن يكراش
        } finally {
            // تمرير للـ Handler الافتراضي دائماً
            try {
                if (mDefaultHandler != null) {
                    mDefaultHandler.uncaughtException(t, e);
                }
            } catch (Throwable ignored) {}
        }
    }
}
