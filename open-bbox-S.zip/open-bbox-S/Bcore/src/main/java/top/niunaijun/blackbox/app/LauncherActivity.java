package top.niunaijun.blackbox.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.Nullable;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.utils.Slog;

public class LauncherActivity extends Activity {
    public static final String TAG = "LauncherActivity";

    public static final String KEY_INTENT = "launch_intent";
    public static final String KEY_PKG = "launch_pkg";
    public static final String KEY_USER_ID = "launch_user_id";

    private boolean mFinished = false;

    public static void launch(Intent intent, int userId) {
        if (intent == null) return;
        try {
            BlackBoxCore.getBActivityManager().startActivity(intent, userId);
        } catch (Throwable e) {
            Slog.e(TAG, "launch failed", e);
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setupTransparentWindow();
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        if (intent == null) {
            safeFinish();
            return;
        }

        Intent launchIntent = null;
        String packageName = null;
        int userId = 0;

        try {
            if (intent.hasExtra(KEY_INTENT)) {
                if (Build.VERSION.SDK_INT >= 33) {
                    launchIntent = intent.getParcelableExtra(KEY_INTENT, Intent.class);
                } else {
                    launchIntent = intent.getParcelableExtra(KEY_INTENT);
                }
            }
            if (intent.hasExtra(KEY_PKG)) {
                packageName = intent.getStringExtra(KEY_PKG);
            }
            userId = intent.getIntExtra(KEY_USER_ID, 0);
        } catch (Throwable e) {
            Slog.e(TAG, "read extras failed", e);
            safeFinish();
            return;
        }

        if (launchIntent == null && packageName == null) {
            safeFinish();
            return;
        }

        try {
            if (launchIntent != null) {
                BlackBoxCore.getBActivityManager().startActivity(launchIntent, userId);
            } else if (packageName != null) {
                Intent mainIntent = BlackBoxCore.getBPackageManager().getLaunchIntentForPackage(packageName, userId);
                if (mainIntent != null) {
                    BlackBoxCore.getBActivityManager().startActivity(mainIntent, userId);
                }
            }
        } catch (Throwable e) {
            Slog.e(TAG, "startActivity failed", e);
        }

        safeFinish();
    }

    private void setupTransparentWindow() {
        try {
            Window window = getWindow();
            if (window == null) return;

            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setStatusBarColor(Color.TRANSPARENT);
                window.setNavigationBarColor(Color.TRANSPARENT);
            }

            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = 1;
            lp.height = 1;
            lp.alpha = 0f;
            window.setAttributes(lp);
        } catch (Throwable ignored) {
        }
    }

    private void safeFinish() {
        if (mFinished) return;
        mFinished = true;
        try {
            finish();
            overridePendingTransition(0, 0);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onBackPressed() {
    }
}
