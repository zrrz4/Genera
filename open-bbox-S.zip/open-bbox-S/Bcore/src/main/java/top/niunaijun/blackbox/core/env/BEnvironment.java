package top.niunaijun.blackbox.core.env;

import android.content.Context;
import android.os.Build;
import android.os.Environment;

import top.niunaijun.blackbox.utils.compat.BuildCompat;
import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Locale;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.utils.FileUtils;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.utils.Slog;
import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class BEnvironment {
    private static final String TAG = "BEnvironment";

    // ================================================================
    // ✅ المسار الداخلي (للبيانات الحساسة)
    // ================================================================
    private static final File sVBoxRoot = BlackBoxCore.getContext().getFilesDir();

    // ================================================================
    // ✅ المسار الخارجي الثابت (مستوحى من المشروع الثاني)
    // هذه هي الطريقة الأكثر استقراراً على Android 16
    // ================================================================
    private static final File sExternalVBoxRoot = new File("/storage/emulated/0/blackbox");

    public static void load() {
        // إنشاء المجلدات الداخلية
        FileUtils.mkdirs(sVBoxRoot);
        FileUtils.mkdirs(getSystemDir());
        FileUtils.mkdirs(getCacheDir());
        FileUtils.mkdirs(getProcDir());

        // إنشاء المجلدات الخارجية (باستخدام المسار الثابت)
        FileUtils.mkdirs(sExternalVBoxRoot);
        FileUtils.mkdirs(new File(sExternalVBoxRoot, "Android/data"));
        FileUtils.mkdirs(new File(sExternalVBoxRoot, "Android/obb"));

        Slog.d(TAG, "BEnvironment load completed. External root: " + sExternalVBoxRoot.getAbsolutePath());
    }

    // ================================================================
    // ✅ باقي الدوال (مع استخدام المسار الثابت للخارجي)
    // ================================================================

    public static File getVBoxRoot() {
        return sVBoxRoot;
    }

    public static ArrayList<String> getAllDex(String str) {
        File appDir = getAppDir(str);
        ArrayList<String> arrayList = new ArrayList<>();
        File[] listFiles = appDir.listFiles((FilenameFilter) (dir, name) -> str.endsWith(".apk"));
        if (listFiles != null) {
            for (File file : listFiles) {
                if (BuildCompat.isUpsideDownCake()) {
                    try {
                        file.setReadOnly();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }
                arrayList.add(file.getAbsolutePath());
            }
        }
        return arrayList;
    }

    public static File getSystemDir() {
        return new File(sVBoxRoot, "system");
    }

    public static File getProcDir() {
        return new File(sVBoxRoot, "proc");
    }

    public static File getCacheDir() {
        return new File(sVBoxRoot, "cache");
    }

    public static File getUserDir(int userId) {
        return new File(sVBoxRoot, String.format(Locale.ENGLISH, "data/user/%d", userId));
    }

    public static File getDeDataDir(String packageName, int userId) {
        return new File(sVBoxRoot, String.format(Locale.ENGLISH, "data/user_de/%d/%s", userId, packageName));
    }

    public static File getDataDir(String packageName, int userId) {
        return new File(sVBoxRoot, String.format(Locale.ENGLISH, "data/user/%d/%s", userId, packageName));
    }

    public static File getAppDir(String packageName) {
        return new File(sVBoxRoot, "data/app/" + packageName);
    }

    public static File getBaseApkDir(String packageName) {
        return new File(getAppDir(packageName), "base.apk");
    }

    public static File getUserInfoConf() {
        return new File(getSystemDir(), "user.conf");
    }

    public static File getAccountsConf() {
        return new File(getSystemDir(), "accounts.conf");
    }

    public static File getUidConf() {
        return new File(getSystemDir(), "uid.conf");
    }

    public static File getSharedUserConf() {
        return new File(getSystemDir(), "shared-user.conf");
    }

    public static File getXPModuleConf() {
        return new File(getSystemDir(), "xposed-module.conf");
    }

    public static File getFakeLocationConf() {
        return new File(getSystemDir(), "fake-location.conf");
    }

    public static File getFakeDeviceConf() {
        return new File(getSystemDir(), "fake-device.conf");
    }

    public static File getPackageConf(String packageName) {
        return new File(getAppDir(packageName), "package.conf");
    }

    // ================================================================
    // ✅ دوال المسار الخارجي (جميعها تستخدم المسار الثابت sExternalVBoxRoot)
    // ================================================================

    public static File getExternalStorageDirectory() {
        return sExternalVBoxRoot;
    }

    public static File getExternalDataDir(String packageName) {
        return new File(getExternalStorageDirectory(), String.format(Locale.ENGLISH, "Android/data/%s", packageName));
    }

    public static File getExternalObbDir(String packageName) {
        return new File(getExternalStorageDirectory(), String.format(Locale.ENGLISH, "Android/obb/%s/", packageName));
    }

    public static File getProcDir(int pid) {
        File file = new File(getProcDir(), String.format(Locale.ENGLISH, "%d", pid));
        FileUtils.mkdirs(file);
        return file;
    }

    public static File getExternalDataFilesDir(String packageName) {
        return new File(getExternalDataDir(packageName), "files");
    }

    public static File getDataFilesDir(String packageName, int userId) {
        return new File(getDataDir(packageName, userId), "files");
    }

    public static File getExternalDataCacheDir(String packageName) {
        return new File(getExternalDataDir(packageName), "cache");
    }

    public static File getDataCacheDir(String packageName, int userId) {
        return new File(getDataDir(packageName, userId), "cache");
    }

    public static File getDataLibDir(String packageName, int userId) {
        return new File(getDataDir(packageName, userId), "lib");
    }

    public static File getDataDatabasesDir(String packageName, int userId) {
        return new File(getDataDir(packageName, userId), "databases");
    }

    public static File getAppRootDir() {
        return getAppDir("");
    }

    public static File getAppLibDir(String packageName) {
        return new File(getAppDir(packageName), "lib");
    }

    public static File getXSharedPreferences(String packageName, String prefFileName) {
        return new File(BEnvironment.getDataDir(packageName, BActivityThread.getUserId()), "shared_prefs/" + prefFileName + ".xml");
    }
}