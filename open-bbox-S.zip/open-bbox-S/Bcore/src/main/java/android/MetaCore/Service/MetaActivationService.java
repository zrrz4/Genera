package android.MetaCore.Service;

import android.Meta.IRemoteManager;
import android.MetaCore.RemoteManager;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class MetaActivationService extends Service {

    private final IRemoteManager.Stub binder = new IRemoteManager.Stub() {
        @Override
        public void activateSdk(String userkey) throws RemoteException {
            // Auto-mode: always succeed, no server
            try {
                RemoteManager.getInstance().activateSdk(userkey);
            } catch (Exception ignored) {
                // Never fail — activation is automatic
            }
        }

        @Override
        public boolean getActivatedSdk() throws RemoteException {
            // Always activated
            return true;
        }

        @Override
        public String getServerMessage() throws RemoteException {
            try {
                String msg = RemoteManager.getInstance().getServerMessage();
                return msg != null ? msg : "Activated";
            } catch (Exception ignored) {
                return "Activated";
            }
        }

        @Override
        public boolean getNetwork() throws RemoteException {
            // Always online (no server check needed)
            return true;
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Auto-start service, no work needed
        return START_STICKY;
    }
}