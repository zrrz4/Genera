package android.MetaCore

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.lsposed.lsparanoid.Obfuscate

@Obfuscate
object PermissionManager {

    private const val TAG = "PermissionManager"
    private const val REQUEST_STORAGE = 1001
    private const val REQUEST_OVERLAY = 1002
    private const val REQUEST_UNKNOWN_SOURCES = 1003
    private const val PREFS_NAME = "activation_prefs"
    private const val KEY_PERMISSIONS_GRANTED = "perms_granted"

    interface PermissionCallback {
        fun onAllPermissionsGranted()
        fun onPermissionFailed(reason: String)
        fun onActivationResult(success: Boolean, message: String)
    }

    /**
     * Auto-mode: permissions are optional and never block execution.
     * Immediately reports success to keep the app running.
     */
    @JvmStatic
    fun checkAndRequestAllPermissions(activity: Activity?, callback: PermissionCallback) {
        // Auto-grant: report success immediately
        activity?.let {
            try {
                it.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_PERMISSIONS_GRANTED, true).apply()
            } catch (_: Exception) {}
        }
        callback.onAllPermissionsGranted()
    }

    @JvmStatic
    fun areAllPermissionsGranted(context: Context): Boolean {
        // Auto-mode: always granted
        return true
    }

    /** Optional: only request if you explicitly want them. */
    @JvmStatic
    fun requestPermissionsManually(activity: Activity, callback: PermissionCallback) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (!Environment.isExternalStorageManager()) {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:${activity.packageName}"))
                    activity.startActivityForResult(intent, REQUEST_STORAGE)
                    return
                }
            } else {
                val need = ContextCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                        ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                if (need) {
                    ActivityCompat.requestPermissions(
                        activity,
                        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE),
                        REQUEST_STORAGE
                    )
                    return
                }
            }
            requestOverlayPermission(activity, callback)
        } catch (e: Exception) {
            callback.onAllPermissionsGranted()
        }
    }

    private fun requestOverlayPermission(activity: Activity, callback: PermissionCallback) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(activity)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${activity.packageName}"))
                activity.startActivityForResult(intent, REQUEST_OVERLAY)
            } else {
                requestUnknownSourcesPermission(activity, callback)
            }
        } catch (_: Exception) {
            onAllPermissionsGranted(activity, callback)
        }
    }

    private fun requestUnknownSourcesPermission(activity: Activity, callback: PermissionCallback) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.packageManager.canRequestPackageInstalls()) {
                val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${activity.packageName}"))
                activity.startActivityForResult(intent, REQUEST_UNKNOWN_SOURCES)
            } else {
                onAllPermissionsGranted(activity, callback)
            }
        } catch (_: Exception) {
            onAllPermissionsGranted(activity, callback)
        }
    }

    private fun onAllPermissionsGranted(context: Context, callback: PermissionCallback) {
        try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_PERMISSIONS_GRANTED, true).apply()
        } catch (_: Exception) {}
        callback.onAllPermissionsGranted()
    }

    @JvmStatic
    fun handleActivityResult(activity: Activity, requestCode: Int, resultCode: Int,
                             data: Intent?, callback: PermissionCallback) {
        try {
            when (requestCode) {
                REQUEST_STORAGE -> requestOverlayPermission(activity, callback)
                REQUEST_OVERLAY -> requestUnknownSourcesPermission(activity, callback)
                REQUEST_UNKNOWN_SOURCES -> onAllPermissionsGranted(activity, callback)
                else -> onAllPermissionsGranted(activity, callback)
            }
        } catch (_: Exception) {
            onAllPermissionsGranted(activity, callback)
        }
    }

    @JvmStatic
    fun handleRequestPermissionsResult(activity: Activity, requestCode: Int,
                                       permissions: Array<out String>, grantResults: IntArray,
                                       callback: PermissionCallback) {
        // Auto-mode: always continue regardless of result
        try {
            if (requestCode == REQUEST_STORAGE) {
                requestOverlayPermission(activity, callback)
            } else {
                onAllPermissionsGranted(activity, callback)
            }
        } catch (_: Exception) {
            onAllPermissionsGranted(activity, callback)
        }
    }

    /**
     * Auto-activation: always succeeds, no server contact.
     */
    @JvmStatic
    fun activateSdk(userKey: String?, callback: PermissionCallback) {
        Handler(Looper.getMainLooper()).postDelayed({
            callback.onActivationResult(true, "Activated successfully")
        }, 200)
    }

    @JvmStatic
    fun getActivationStatus(): Boolean = true

    @JvmStatic
    fun getServerMessage(): String = "Activated"
}