package android.MetaCore

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.lsposed.lsparanoid.Obfuscate
import top.niunaijun.blackbox.BlackBoxCore
import java.text.SimpleDateFormat
import java.util.*

@Obfuscate
object nk {

    // ========== Configuration ==========
    private const val PREFERENCE_NAME = "activation_prefs"
    private const val KEY_ACTIVATED = "activated"
    private const val KEY_EXPIRY = "expiry"
    private const val KEY_HIDDEN_STATUS = "hidden_status"

    // Date formats
    private val DATE_FORMATS = arrayOf(
        "yyyy-MM-dd",
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd'T'HH:mm:ss"
    )

    // Time constants
    private const val DAY_MILLIS = 86400000L
    private const val HOUR_MILLIS = 3600000L

    // Expiry far in the future (year 2099) — effectively permanent activation
    private const val DEFAULT_EXPIRY = "2099-12-31"

    @JvmField
    @Volatile
    var Msg: String = "Activated"

    @Volatile
    private var hiddenFlag: Boolean = true

    // ----------------------------------------------------------------------
    // Public API
    // ----------------------------------------------------------------------

    @JvmStatic
    fun GAH(): Boolean = true

    @JvmStatic
    fun getActivatedSdk(): Boolean {
        val context = BlackBoxCore.getContext() ?: run {
            Msg = "Activated (no context)"
            return true
        }
        val sp = context.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE)

        // Force activation if not set
        if (!sp.getBoolean(KEY_ACTIVATED, false)) {
            sp.edit()
                .putBoolean(KEY_ACTIVATED, true)
                .putString(KEY_EXPIRY, DEFAULT_EXPIRY)
                .putString(KEY_HIDDEN_STATUS, "true")
                .apply()
        }

        val expiryStr = sp.getString(KEY_EXPIRY, DEFAULT_EXPIRY) ?: DEFAULT_EXPIRY
        return try {
            val expiryDate = parseDate(expiryStr)
            val currentTime = System.currentTimeMillis()
            val expiryTime = expiryDate.time
            if (currentTime < expiryTime) {
                val daysLeft = (expiryTime - currentTime) / DAY_MILLIS
                Msg = "License valid for $daysLeft days"
                true
            } else {
                // Auto-renew — never expire
                sp.edit().putString(KEY_EXPIRY, DEFAULT_EXPIRY).apply()
                Msg = "License auto-renewed"
                true
            }
        } catch (e: Exception) {
            Msg = "Activated"
            true
        }
    }

    private fun parseDate(dateStr: String): Date {
        for (format in DATE_FORMATS) {
            try {
                return SimpleDateFormat(format, Locale.getDefault()).parse(dateStr)!!
            } catch (ignored: Exception) {}
        }
        throw IllegalArgumentException("Unparseable date: $dateStr")
    }

    @JvmStatic
    fun getServerMessage(): String = Msg

    @JvmStatic
    fun ismsg(msg: String?) {
        val ctx = BlackBoxCore.getContext() ?: return
        Handler(Looper.getMainLooper()).post {
            try { Toast.makeText(ctx, msg ?: "", Toast.LENGTH_SHORT).show() } catch (_: Exception) {}
        }
    }

    @JvmStatic
    fun setHidden(status: String?) {
        hiddenFlag = true
        BlackBoxCore.getContext()?.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE)
            ?.edit()?.putString(KEY_HIDDEN_STATUS, "true")?.apply()
        Msg = "Hidden flag set to true"
    }

    @JvmStatic
    fun setHidden(value: Boolean) = setHidden("true")

    @JvmStatic
    fun getUrlHidden(): String = ""

    @JvmStatic
    fun 获取接口地址(): String = ""

    @JvmStatic
    fun isSystemApp(): Boolean {
        getActivatedSdk()
        Msg = "Activation successful"
        return true
    }

    @JvmStatic
    fun checkExpiryManually(): String {
        val context = BlackBoxCore.getContext() ?: return "Activated permanently"
        val sp = context.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE)
        val expiryStr = sp.getString(KEY_EXPIRY, DEFAULT_EXPIRY) ?: DEFAULT_EXPIRY
        return try {
            val expiryDate = parseDate(expiryStr)
            val remaining = expiryDate.time - System.currentTimeMillis()
            if (remaining > 0) {
                val days = remaining / DAY_MILLIS
                val hours = (remaining % DAY_MILLIS) / HOUR_MILLIS
                "License valid for $days days $hours hours"
            } else {
                "Activated permanently"
            }
        } catch (e: Exception) {
            "Activated permanently"
        }
    }

    @JvmStatic
    fun loadSavedStatus() {
        try {
            val context = BlackBoxCore.getContext() ?: return
            val sp = context.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE)
            sp.edit()
                .putBoolean(KEY_ACTIVATED, true)
                .putString(KEY_HIDDEN_STATUS, "true")
                .putString(KEY_EXPIRY, DEFAULT_EXPIRY)
                .apply()
            hiddenFlag = true
            getActivatedSdk()
        } catch (_: Exception) {}
    }
}