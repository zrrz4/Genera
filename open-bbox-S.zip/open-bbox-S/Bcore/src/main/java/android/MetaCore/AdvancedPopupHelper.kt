package android.MetaCore

import android.app.Activity
import android.app.Dialog
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import org.lsposed.lsparanoid.Obfuscate

/**
 * Auto-mode version of AdvancedPopupHelper.
 * No server, no popup shown — activation is automatic.
 * The popup code is kept only for optional manual use via forceShow().
 */
@Obfuscate
object AdvancedPopupHelper {

    private val handler = Handler(Looper.getMainLooper())

    /**
     * Called by the app for activation popup.
     * Now a no-op — activation is automatic (always true).
     * Returns true immediately so the caller continues normally.
     */
    @JvmStatic
    fun show(activity: Activity?): Boolean {
        // Auto-mode: skip the popup entirely
        return true
    }

    /**
     * Only used if you ever want to display the popup manually.
     * Does NOT contact any server — loads local HTML only.
     */
    @JvmStatic
    fun forceShow(activity: Activity) {
        if (activity.isFinishing || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && activity.isDestroyed)) return
        handler.post { showPopup(activity) }
    }

    private fun showPopup(activity: Activity) {
        try {
            val dialog = Dialog(activity, android.R.style.Theme_Translucent_NoTitleBar)
            dialog.setCancelable(false)

            val webView = WebView(activity)
            webView.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
            }
            webView.setBackgroundColor(0x00000000)
            webView.webViewClient = WebViewClient()

            val deviceInfo = """
                {
                    "manufacturer": "${Build.MANUFACTURER}",
                    "model": "${Build.MODEL}",
                    "release": "${Build.VERSION.RELEASE}",
                    "sdk": ${Build.VERSION.SDK_INT}
                }
            """.trimIndent()

            webView.addJavascriptInterface(
                PopupJsInterface(dialog, deviceInfo),
                "Android"
            )

            val htmlContent = """
                <html>
                <head><meta charset="UTF-8"></head>
                <body style="background:transparent;color:#fff;font-family:sans-serif;text-align:center;">
                    <h2>Activated</h2>
                    <p>Auto mode enabled</p>
                    <script>
                        // Auto-close after 1 second
                        setTimeout(function(){ Android.close(); }, 1000);
                    </script>
                </body>
                </html>
            """.trimIndent()

            webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
            dialog.setContentView(webView)
            dialog.show()

            dialog.window?.apply {
                setLayout(dp(activity, 250), dp(activity, 400))
                setGravity(Gravity.CENTER)
                addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                setDimAmount(0.6f)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun dp(activity: Activity, value: Int): Int {
        return (value * activity.resources.displayMetrics.density).toInt()
    }

    private class PopupJsInterface(
        private val dialog: Dialog,
        private val deviceInfo: String
    ) {
        @android.webkit.JavascriptInterface
        fun close() { dialog.dismiss() }

        @android.webkit.JavascriptInterface
        fun getDeviceInfo(): String = deviceInfo

        @android.webkit.JavascriptInterface
        fun isActivated(): Boolean = true
    }
}