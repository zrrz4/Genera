package android.MetaCore

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import org.lsposed.lsparanoid.Obfuscate

@Obfuscate
object db {

    private const val CONNECT_TIMEOUT = 15000
    private const val READ_TIMEOUT = 15000

    /**
     * Returns an HttpURLConnection ready for use.
     * No server is contacted here — the caller decides.
     * If URL is empty or invalid, a safe dummy connection to localhost is returned
     * so no exception is thrown and the app keeps working.
     */
    @JvmStatic
    @Throws(IOException::class)
    fun isTrue(url: String): HttpURLConnection {
        val safeUrl = if (url.startsWith("http://", ignoreCase = true) ||
            url.startsWith("https://", ignoreCase = true)) {
            url
        } else {
            "http://127.0.0.1/"
        }

        val connection = URL(safeUrl).openConnection() as HttpURLConnection
        connection.connectTimeout = CONNECT_TIMEOUT
        connection.readTimeout = READ_TIMEOUT
        connection.instanceFollowRedirects = true
        return connection
    }

    /**
     * Always returns true — no server check.
     * Kept for compatibility with code that expects a boolean result.
     */
    @JvmStatic
    fun check(url: String?): Boolean = true

    /**
     * Always returns true — automatic activation.
     */
    @JvmStatic
    fun verify(): Boolean = true
}