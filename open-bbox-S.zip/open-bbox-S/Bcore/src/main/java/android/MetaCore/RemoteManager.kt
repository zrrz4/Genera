package android.MetaCore

import android.Meta.IRemoteManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import androidx.core.app.NotificationCompat
import org.lsposed.lsparanoid.Obfuscate
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackbox.core.env.BEnvironment
import java.io.File
import java.util.concurrent.Executors

@Obfuscate
class RemoteManager private constructor() : IRemoteManager.Stub() {

    init {
        nk.loadSavedStatus()
        // Auto-activate everything on creation
        autoActivate()
    }

    override fun activateSdk(userKey: String?) {
        // Auto-mode: always succeed, no server
        autoActivate()
        nk.Msg = "Activated successfully"
    }

    override fun getActivatedSdk(): Boolean {
        // Always true
        nk.Msg = "SDK is activated"
        return true
    }

    override fun getServerMessage(): String = nk.Msg ?: "Activated"

    override fun getNetwork(): Boolean = true

    // ----------------------------------------------------------------------
    // Auto-activation
    // ----------------------------------------------------------------------

    private fun autoActivate() {
        try {
            val ctx = BlackBoxCore.getContext() ?: return
            val sp = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            sp.edit()
                .putBoolean(KEY_ACTIVATED, true)
                .putString(KEY_EXPIRY, "2099-12-31")
                .apply()

            nk.setHidden(true)
            nk.Msg = "Activated"
        } catch (_: Throwable) {}
    }

    // ----------------------------------------------------------------------
    // Online controller — disabled (no server)
    // ----------------------------------------------------------------------

    fun startOnlineController() {
        // No-op: no server sync needed
    }

    // ----------------------------------------------------------------------
    // Notifications (kept for local use only)
    // ----------------------------------------------------------------------

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || notificationChannelCreated) return
        val ctx = BlackBoxCore.getContext() ?: return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        val channel = NotificationChannel(
            NOTIFICATION_CHANNEL_ID,
            NOTIFICATION_CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            enableLights(true)
            lightColor = Color.GREEN
            setShowBadge(true)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(channel)
        notificationChannelCreated = true
    }

    companion object {
        private const val PREF_NAME = "activation_prefs"
        private const val KEY_ACTIVATED = "activated"
        private const val KEY_EXPIRY = "expiry"

        @JvmField
        var sEnableDaemonService = true
        @JvmField
        var sHideRoot = true
        @JvmField
        var sHideXposed = true

        private val executor = Executors.newSingleThreadExecutor()

        private const val NOTIFICATION_CHANNEL_ID = "remote_manager_channel"
        private const val NOTIFICATION_CHANNEL_NAME = "Remote Manager"
        private var notificationChannelCreated = false

        @Volatile
        private var instance: RemoteManager? = null

        @JvmStatic
        fun getInstance(): RemoteManager {
            return instance ?: synchronized(this) {
                instance ?: RemoteManager().also { instance = it }
            }
        }

        @JvmField
        val JUNIT_JAR = File(BEnvironment.getCacheDir(), "junit.apk")
        @JvmField
        val EMPTY_JAR = File(BEnvironment.getCacheDir(), "empty.jar")
    }
}